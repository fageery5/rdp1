import React, { useState, useEffect, useMemo } from 'react';
import { 
  MapPin, 
  Clock, 
  History, 
  CheckCircle2, 
  XCircle, 
  Loader2,
  LogOut,
  LocateFixed,
  Users,
  Search,
  AlertCircle,
  Plus,
  ShieldCheck as ShieldIcon,
  Calendar,
  FileText,
  TrendingUp,
  Building2,
  Smartphone,
  RefreshCcw,
  Trash2,
  Edit2,
  Save,
  X,
  ArrowRight,
  Printer,
  FileSpreadsheet,
  Bell,
  UserPlus,
  UserCheck,
  UserX,
  Hourglass,
  LayoutGrid
} from 'lucide-react';
import { 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar
} from 'recharts';
import { AttendanceStatus, AttendanceRecord, WorkSite, User } from './types';
import { INITIAL_WORK_SITES, MOCK_HISTORY, DEPARTMENTS } from './constants';
import { calculateDistance } from './utils/geoUtils';
import StatsCard from './components/StatsCard';
import AdminSites from './components/AdminSites';
import Login from './components/Login';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [records, setRecords] = useState<AttendanceRecord[]>(MOCK_HISTORY);
  const [workSites, setWorkSites] = useState<WorkSite[]>(INITIAL_WORK_SITES);
  const [departments, setDepartments] = useState<string[]>(DEPARTMENTS);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<{lat: number, lng: number} | null>(null);
  const [activeTab, setActiveTab] = useState<'home' | 'history' | 'dashboard' | 'admin' | 'employees' | 'reports' | 'departments' | 'profile'>('home');
  const [searchFilter, setSearchFilter] = useState('');
  const [selectedReportUser, setSelectedReportUser] = useState<string | 'all'>('all');
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newEmployee, setNewEmployee] = useState({ name: '', phone: '', department: '' });
  
  const [userRolesMap, setUserRolesMap] = useState<{[phone: string]: 'admin' | 'manager' | 'employee'}>({});
  const [toast, setToast] = useState<{message: string, type: 'success' | 'error' | 'info'} | null>(null);
  const [manualRegEmployee, setManualRegEmployee] = useState<{id: string, name: string} | null>(null);
  const [newDeptName, setNewDeptName] = useState('');
  const [currentDeviceId, setCurrentDeviceId] = useState<string>('');

  useEffect(() => {
    let devId = localStorage.getItem('app_device_fingerprint');
    if (!devId) {
      devId = Math.random().toString(36).substring(2, 15);
      localStorage.setItem('app_device_fingerprint', devId);
    }
    setCurrentDeviceId(devId);

    const savedUser = localStorage.getItem('attendance_user');
    if (savedUser) setUser(JSON.parse(savedUser));

    const savedDepts = localStorage.getItem('app_departments');
    if (savedDepts) setDepartments(JSON.parse(savedDepts));

    const savedRoles = localStorage.getItem('app_user_roles');
    if (savedRoles) setUserRolesMap(JSON.parse(savedRoles));

    const savedUsers = localStorage.getItem('app_all_users');
    if (savedUsers) setAllUsers(JSON.parse(savedUsers));
  }, []);

  useEffect(() => {
    localStorage.setItem('app_departments', JSON.stringify(departments));
  }, [departments]);

  useEffect(() => {
    localStorage.setItem('app_user_roles', JSON.stringify(userRolesMap));
  }, [userRolesMap]);

  useEffect(() => {
    localStorage.setItem('app_all_users', JSON.stringify(allUsers));
  }, [allUsers]);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const handleLogin = (name: string, phone: string, department: string): string | null => {
    const isAdmin = name.toLowerCase().includes('مدير') || phone === '999';
    // محاولة جلب المستخدم من القائمة المخزنة أولاً لمعرفة رتبته الحقيقية
    const existingUser = allUsers.find(u => u.phone === phone);
    
    // إذا كان الموظف قيد الانتظار نمنعه
    if (!isAdmin && existingUser && existingUser.status === 'pending') {
      return "عذراً، حسابك قيد الانتظار لموافقة مدير النظام. يرجى المراجعة لاحقاً.";
    }

    const storedRole = userRolesMap[phone] || existingUser?.role;
    const isManager = storedRole === 'manager' || name.includes('رئيس');

    const deviceMap = JSON.parse(localStorage.getItem('registered_devices_map') || '{}');
    if (!isAdmin && !isManager) {
      if (deviceMap[phone] && deviceMap[phone] !== currentDeviceId) {
        return "هذا الحساب مرتبط بجهاز آخر.";
      }
      if (!deviceMap[phone]) {
        deviceMap[phone] = currentDeviceId;
        localStorage.setItem('registered_devices_map', JSON.stringify(deviceMap));
      }
    }

    const newUser: User = {
      id: existingUser?.id || Math.random().toString(36).substr(2, 9),
      name,
      phone,
      department,
      role: isAdmin ? 'admin' : (isManager ? 'manager' : 'employee'),
      deviceId: (isAdmin || isManager) ? undefined : currentDeviceId,
      status: 'active'
    };

    if (!existingUser) {
      setAllUsers(prev => [...prev, newUser]);
    }

    setUser(newUser);
    localStorage.setItem('attendance_user', JSON.stringify(newUser));
    showToast(`مرحباً بك، ${name}`, "success");
    if (isAdmin || isManager) setActiveTab('dashboard');
    return null;
  };

  const addDepartment = () => {
    const trimmed = newDeptName.trim();
    if (trimmed) {
      if (departments.includes(trimmed)) {
        showToast("هذا القسم موجود بالفعل", "error");
        return;
      }
      setDepartments([...departments, trimmed]);
      setNewDeptName('');
      showToast("تم إضافة القسم بنجاح", "success");
    }
  };

  const deleteDepartment = (dept: string) => {
    if (window.confirm(`هل أنت متأكد من حذف قسم "${dept}"؟`)) {
      setDepartments(prev => prev.filter(d => d !== dept));
      showToast(`تم حذف قسم "${dept}"`, "info");
    }
  };

  const handleApproveUser = (id: string) => {
    setAllUsers(prev => prev.map(u => u.id === id ? { ...u, status: 'active' } : u));
    showToast("تم الموافقة على الموظف وتفعيل حسابه", "success");
  };

  const handleRejectUser = (id: string) => {
    setAllUsers(prev => prev.filter(u => u.id !== id));
    showToast("تم رفض طلب الإضافة", "info");
  };

  const handleManualAttendance = (employeeId: string, employeeName: string, type: AttendanceStatus) => {
    if (!user) return;
    const newRecord: AttendanceRecord = {
      id: Math.random().toString(36).substr(2, 9),
      userId: employeeId,
      userName: employeeName,
      type,
      timestamp: new Date(),
      location: currentLocation || { lat: 0, lng: 0 },
      isWithinRange: true,
      distance: 0,
      siteName: nearestSite?.name || "تسجيل إداري",
      isManual: true,
      recordedBy: user.id,
      recordedByName: user.name
    };
    setRecords(prev => [newRecord, ...prev]);
    setManualRegEmployee(null);
    showToast(`تم تسجيل ${type} للموظف ${employeeName}`, "success");
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('attendance_user');
    setActiveTab('home');
  };

  const addSite = (site: WorkSite) => {
    setWorkSites(prev => [...prev, site]);
    showToast(`تم إضافة موقع "${site.name}" بنجاح`, "success");
  };

  const deleteSite = (id: string) => {
    if (window.confirm("هل أنت متأكد من حذف هذا الموقع؟")) {
      setWorkSites(prev => prev.filter(s => s.id !== id));
      showToast("تم حذف الموقع بنجاح", "info");
    }
  };

  const handleAddEmployeeRequest = (e: React.FormEvent) => {
    e.preventDefault();
    const { name, phone, department } = newEmployee;
    if (!name || !phone || (!department && user?.role === 'admin')) {
      showToast("يرجى ملء جميع الحقول", "error");
      return;
    }

    const existing = allUsers.find(u => u.phone === phone);
    if (existing) {
      showToast("هذا الرقم مسجل مسبقاً", "error");
      return;
    }

    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      phone,
      department: department || user?.department || '',
      role: 'employee',
      status: user?.role === 'admin' ? 'active' : 'pending',
      addedBy: user?.id
    };

    setAllUsers(prev => [...prev, newUser]);
    setNewEmployee({ name: '', phone: '', department: '' });
    setShowAddForm(false);
    showToast(user?.role === 'admin' ? "تم إضافة الموظف بنجاح" : "تم إرسال طلب إضافة الموظف للمدير", "success");
  };

  // وظيفة تغيير الرتبة بعد الإصلاح لضمان تحديث الواجهة والذاكرة
  const toggleUserRole = (phone: string) => {
    setAllUsers(prev => {
      // Explicitly type the return array to match User[] and avoid "string" role issues
      const updated: User[] = prev.map(u => {
        if (u.phone === phone) {
          // Explicitly type nextRole to match the expected union type for role
          const nextRole: 'manager' | 'employee' = u.role === 'employee' ? 'manager' : 'employee';
          // تحديث خريطة الأدوار أيضاً لضمان تسجيل دخول صحيح
          setUserRolesMap(map => ({ ...map, [phone]: nextRole }));
          return { ...u, role: nextRole };
        }
        return u;
      });
      return updated;
    });
    showToast("تم تحديث رتبة الموظف بنجاح", "success");
  };

  const resetEmployeeDevice = (phone: string) => {
    if (window.confirm('هل أنت متأكد من فك ربط جهاز هذا الموظف؟')) {
      const deviceMap = JSON.parse(localStorage.getItem('registered_devices_map') || '{}');
      if (deviceMap[phone]) {
        delete deviceMap[phone];
        localStorage.setItem('registered_devices_map', JSON.stringify(deviceMap));
        showToast("تم فك ربط الجهاز بنجاح", "success");
        // نحتاج لتحديث الحالة لإعادة تحميل واجهة الموظفين
        setAllUsers([...allUsers]);
      }
    }
  };

  useEffect(() => {
    if ("geolocation" in navigator && user) {
      const watcher = navigator.geolocation.watchPosition(
        (pos) => setCurrentLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        null, { enableHighAccuracy: true }
      );
      return () => navigator.geolocation.clearWatch(watcher);
    }
  }, [user]);

  const { nearestSite, distanceToNearest } = useMemo(() => {
    if (!currentLocation || workSites.length === 0) return { nearestSite: null, distanceToNearest: null };
    let nearest = workSites[0];
    let minDist = calculateDistance(currentLocation.lat, currentLocation.lng, nearest.lat, nearest.lng);
    workSites.forEach(site => {
      const d = calculateDistance(currentLocation.lat, currentLocation.lng, site.lat, site.lng);
      if (d < minDist) { minDist = d; nearest = site; }
    });
    return { nearestSite: nearest, distanceToNearest: Math.round(minDist) };
  }, [currentLocation, workSites]);

  const isWithinWorkSite = nearestSite && distanceToNearest !== null && distanceToNearest <= nearestSite.radius;

  const handleAttendance = async (type: AttendanceStatus) => {
    if (!currentLocation || !user) return;
    setLoading(true);
    setTimeout(() => {
      const newRecord: AttendanceRecord = {
        id: Math.random().toString(36).substr(2, 9),
        userId: user.id, userName: user.name, userPhone: user.phone,
        type, timestamp: new Date(), location: currentLocation,
        isWithinRange: !!isWithinWorkSite, distance: distanceToNearest || 0,
        siteName: nearestSite?.name
      };
      setRecords(prev => [newRecord, ...prev]);
      setLoading(false);
      showToast(`تم تسجيل ${type} بنجاح`, "success");
    }, 1200);
  };

  const adminStats = useMemo(() => {
    const today = new Date().toDateString();
    const filteredUsers = user?.role === 'manager' ? allUsers.filter(u => u.department === user.department) : allUsers;
    const presentToday = new Set(records.filter(r => new Date(r.timestamp).toDateString() === today && r.type === AttendanceStatus.IN).map(r => r.userId));
    return {
      totalEmployees: filteredUsers.length,
      presentToday: presentToday.size,
      activeSites: workSites.length,
      violations: records.filter(r => !r.isWithinRange).length
    };
  }, [records, workSites, user, allUsers]);

  const departmentStats = useMemo(() => {
    return departments.map(dept => ({
      name: dept,
      employeeCount: allUsers.filter(u => u.department === dept).length,
      presentToday: records.filter(r => {
        const isToday = new Date(r.timestamp).toDateString() === new Date().toDateString();
        const userInDept = allUsers.find(u => u.id === r.userId)?.department === dept;
        return isToday && r.type === AttendanceStatus.IN && userInDept;
      }).length
    }));
  }, [departments, allUsers, records]);

  if (!user) return <Login onLogin={handleLogin} departments={departments} />;

  return (
    <div className="min-h-screen pb-24 md:pb-8 flex flex-col bg-slate-50">
      {toast && (
        <div className={`fixed top-4 left-1/2 -translate-x-1/2 z-[100] px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top border ${toast.type === 'success' ? 'bg-green-500 text-white border-green-600' : 'bg-red-500 text-white border-red-600'}`}>
          <span className="text-sm font-bold">{toast.message}</span>
        </div>
      )}

      {manualRegEmployee && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[110] flex items-center justify-center p-4">
          <div className="bg-white rounded-[2.5rem] w-full max-w-sm p-8 shadow-2xl">
            <h3 className="text-xl font-black text-center mb-8">تسجيل يدوي لـ {manualRegEmployee.name}</h3>
            <div className="grid grid-cols-2 gap-4">
              <button onClick={() => handleManualAttendance(manualRegEmployee.id, manualRegEmployee.name, AttendanceStatus.IN)} className="bg-green-500 text-white py-4 rounded-2xl font-bold">حضور</button>
              <button onClick={() => handleManualAttendance(manualRegEmployee.id, manualRegEmployee.name, AttendanceStatus.OUT)} className="bg-blue-600 text-white py-4 rounded-2xl font-bold">انصراف</button>
            </div>
            <button onClick={() => setManualRegEmployee(null)} className="w-full mt-6 text-gray-400 font-bold">إلغاء</button>
          </div>
        </div>
      )}

      <header className="bg-white border-b border-gray-100 px-6 py-4 sticky top-0 z-50 shadow-sm no-print">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-xl shadow-lg ${user.role !== 'employee' ? 'bg-indigo-600' : 'bg-blue-600'}`}>
              {user.role !== 'employee' ? <ShieldIcon className="text-white w-6 h-6" /> : <Clock className="text-white w-6 h-6" />}
            </div>
            <div>
              <h1 className="text-lg font-black text-gray-800">{user.role === 'admin' ? 'لوحة الإدارة' : (user.role === 'manager' ? 'لوحة رئيس القسم' : 'نظام الحضور')}</h1>
              <p className="text-[10px] text-blue-600 font-bold">مستشفى دنقلا التخصصي</p>
            </div>
          </div>
          <button onClick={handleLogout} className="text-gray-400 p-2 bg-gray-50 rounded-full border hover:text-red-600 transition-colors"><LogOut size={20} /></button>
        </div>
      </header>

      <main className="flex-1 max-w-6xl mx-auto w-full p-4 md:p-6 space-y-6">
        <div className="hidden md:flex flex-wrap gap-4 bg-white p-1.5 rounded-2xl border w-fit no-print">
          {[
            { id: 'home', label: 'الرئيسية' },
            { id: 'reports', label: 'الأرشفة' },
            { id: 'history', label: 'السجلات' },
            { id: 'dashboard', label: 'الإحصائيات', adminOrManager: true },
            { id: 'employees', label: 'الموظفين', adminOrManager: true },
            { id: 'departments', label: 'الأقسام', adminOrManager: true },
            { id: 'admin', label: 'المواقع', adminOnly: true },
          ].filter(t => !t.adminOnly || user.role === 'admin')
           .filter(t => !t.adminOrManager || user.role !== 'employee')
           .map((tab) => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id as any)} className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${activeTab === tab.id ? 'bg-indigo-600 text-white shadow-md' : 'text-gray-500 hover:bg-gray-50'}`}>
              {tab.label}
            </button>
          ))}
        </div>

        {activeTab === 'departments' && (user.role === 'admin' || user.role === 'manager') && (
          <div className="space-y-6 animate-in fade-in">
            <div className="bg-white p-8 rounded-3xl border shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <h2 className="text-2xl font-black text-gray-800">أقسام المستشفى</h2>
                <p className="text-sm text-gray-500">قائمة الأقسام المسجلة وتوزيع الكوادر</p>
              </div>
              {user.role === 'admin' && (
                <div className="flex gap-2 w-full md:w-auto">
                  <input 
                    type="text" 
                    placeholder="اسم القسم الجديد..." 
                    className="flex-1 bg-slate-50 border rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-500" 
                    value={newDeptName} 
                    onChange={e => setNewDeptName(e.target.value)} 
                  />
                  <button onClick={addDepartment} className="bg-indigo-600 text-white px-6 py-2 rounded-xl font-bold flex items-center gap-2 hover:bg-indigo-700 transition-colors"><Plus size={18}/> إضافة</button>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {departmentStats.map((dept, idx) => (
                <div key={idx} className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm hover:shadow-xl transition-all group relative overflow-hidden">
                   <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-50 rounded-bl-[4rem] -mr-8 -mt-8 transition-all group-hover:bg-indigo-600/10"></div>
                   <div className="relative z-10">
                      <div className="flex justify-between items-start mb-6">
                         <div className="p-3 bg-indigo-600 text-white rounded-2xl shadow-lg shadow-indigo-100">
                            <Building2 size={24} />
                         </div>
                         {user.role === 'admin' && (
                           <button onClick={() => deleteDepartment(dept.name)} className="text-gray-300 hover:text-red-500 p-2 transition-colors"><Trash2 size={18} /></button>
                         )}
                      </div>
                      <h3 className="text-xl font-black text-gray-800 mb-4">{dept.name}</h3>
                      <div className="flex gap-3">
                         <div className="flex-1 bg-slate-50 p-3 rounded-2xl text-center border border-gray-50">
                            <p className="text-[10px] text-gray-400 font-bold uppercase mb-1">الكوادر</p>
                            <p className="text-lg font-black text-gray-800">{dept.employeeCount}</p>
                         </div>
                         <div className="flex-1 bg-green-50 p-3 rounded-2xl text-center border border-green-100">
                            <p className="text-[10px] text-green-600 font-bold uppercase mb-1">الحضور اليوم</p>
                            <p className="text-lg font-black text-green-700">{dept.presentToday}</p>
                         </div>
                      </div>
                   </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'home' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in fade-in">
             <div className="lg:col-span-2 space-y-6">
                <div className="bg-white p-8 rounded-3xl shadow-sm border relative overflow-hidden">
                  <div className={`absolute top-0 left-0 w-full h-1 ${user.role !== 'employee' ? 'bg-indigo-600' : 'bg-blue-600'}`}></div>
                  <div className="flex flex-col md:flex-row gap-8 items-center">
                    <div className="flex-1 space-y-6 w-full text-right">
                      <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2"><LocateFixed className="w-5 h-5 text-indigo-500" /> الموقع المباشر</h2>
                      <div className="bg-slate-50 p-6 rounded-2xl border">
                         <p className="text-xs text-gray-500">الموقع الحالي: <span className="font-bold text-gray-800">{nearestSite?.name || 'جاري التحديد...'}</span></p>
                         <div className="h-2 w-full bg-gray-200 rounded-full mt-4 overflow-hidden">
                            <div className={`h-full transition-all ${isWithinWorkSite ? 'bg-green-500' : 'bg-red-500'}`} style={{ width: isWithinWorkSite ? '100%' : '30%' }}></div>
                         </div>
                         <div className="flex justify-between mt-2 text-[11px] font-bold text-gray-500">
                            <span>المسافة: {distanceToNearest} متر</span>
                            <span>النطاق: {nearestSite?.radius} متر</span>
                         </div>
                      </div>
                    </div>
                    <div className="flex flex-col gap-4 w-full md:w-64 no-print">
                       <button disabled={loading || !isWithinWorkSite} onClick={() => handleAttendance(AttendanceStatus.IN)} className="p-6 rounded-2xl bg-green-500 text-white font-bold text-xl shadow-lg disabled:opacity-40 transition-all active:scale-95 flex justify-between items-center">حضور {loading && <Loader2 className="animate-spin" />}</button>
                       <button disabled={loading || !isWithinWorkSite} onClick={() => handleAttendance(AttendanceStatus.OUT)} className="p-6 rounded-2xl bg-blue-600 text-white font-bold text-xl shadow-lg disabled:opacity-40 transition-all active:scale-95 flex justify-between items-center">انصراف {loading && <Loader2 className="animate-spin" />}</button>
                    </div>
                  </div>
                </div>
             </div>
          </div>
        )}

        {activeTab === 'employees' && (user.role === 'admin' || user.role === 'manager') && (
          <div className="space-y-6">
            <div className="bg-white p-8 rounded-3xl border shadow-sm no-print">
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h2 className="text-2xl font-black text-gray-800">إدارة الكوادر</h2>
                  <p className="text-sm text-gray-400">
                    {user.role === 'admin' ? 'مدير النظام: صلاحيات كاملة' : `رئيس قسم ${user.department}: إدارة الموظفين`}
                  </p>
                </div>
                <button 
                  onClick={() => setShowAddForm(!showAddForm)}
                  className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-indigo-700 shadow-lg shadow-indigo-100 transition-all"
                >
                  <UserPlus size={20} /> إضافة موظف جديد
                </button>
              </div>

              {showAddForm && (
                <form onSubmit={handleAddEmployeeRequest} className="mb-8 p-6 bg-slate-50 border rounded-2xl grid grid-cols-1 md:grid-cols-4 gap-4 animate-in slide-in-from-top">
                  <input required placeholder="الاسم الكامل" className="bg-white p-3 rounded-xl border text-sm" value={newEmployee.name} onChange={e => setNewEmployee({...newEmployee, name: e.target.value})} />
                  <input required placeholder="رقم الهاتف" className="bg-white p-3 rounded-xl border text-sm" value={newEmployee.phone} onChange={e => setNewEmployee({...newEmployee, phone: e.target.value})} />
                  {user.role === 'admin' && (
                    <select required className="bg-white p-3 rounded-xl border text-sm" value={newEmployee.department} onChange={e => setNewEmployee({...newEmployee, department: e.target.value})}>
                      <option value="">اختر القسم</option>
                      {departments.map(d => <option key={d} value={d}>{d}</option>)}
                    </select>
                  )}
                  <button type="submit" className="bg-indigo-600 text-white font-bold rounded-xl py-3 hover:bg-indigo-700">إرسال الطلب</button>
                </form>
              )}

              {user.role === 'admin' && allUsers.some(u => u.status === 'pending') && (
                <div className="mb-10">
                  <h3 className="text-sm font-black text-indigo-600 mb-4 flex items-center gap-2 uppercase tracking-widest">
                    <Hourglass className="w-4 h-4 animate-pulse" /> طلبات معلقة بانتظار موافقتك
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {allUsers.filter(u => u.status === 'pending').map(pendingUser => (
                      <div key={pendingUser.id} className="p-6 bg-indigo-50 border border-indigo-100 rounded-3xl flex justify-between items-center shadow-sm">
                        <div>
                          <p className="font-black text-gray-800">{pendingUser.name}</p>
                          <p className="text-[10px] text-indigo-500 font-bold">{pendingUser.department} • {pendingUser.phone}</p>
                        </div>
                        <div className="flex gap-2">
                          <button onClick={() => handleApproveUser(pendingUser.id)} className="bg-white text-green-600 p-2.5 rounded-xl border hover:bg-green-600 hover:text-white transition-all shadow-sm"><UserCheck size={18} /></button>
                          <button onClick={() => handleRejectUser(pendingUser.id)} className="bg-white text-red-500 p-2.5 rounded-xl border hover:bg-red-50 transition-all shadow-sm"><UserX size={18} /></button>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="h-px bg-gray-100 my-10"></div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {allUsers.filter(u => user.role === 'admin' || u.department === user.department).map(u => {
                   const deviceMap = JSON.parse(localStorage.getItem('registered_devices_map') || '{}');
                   const hasDevice = !!deviceMap[u.phone];
                   return (
                    <div key={u.id} className={`p-6 rounded-3xl border transition-all relative ${u.status === 'pending' ? 'bg-amber-50/30 border-amber-100 grayscale' : 'bg-slate-50 hover:bg-white hover:shadow-xl'}`}>
                       {u.status === 'pending' && (
                         <div className="absolute top-4 left-4 bg-amber-500 text-white text-[8px] font-black px-2 py-1 rounded-full flex items-center gap-1">
                           <Hourglass size={10} /> قيد الانتظار
                         </div>
                       )}
                       <div className="flex items-center gap-4 mb-6">
                          <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-black shadow-lg shadow-indigo-100">{u.name.charAt(0)}</div>
                          <div className="flex-1 min-w-0">
                             <h4 className="font-bold text-gray-800 truncate">{u.name}</h4>
                             <div className="flex items-center gap-1.5 flex-wrap">
                                <p className="text-[10px] text-gray-400 font-mono" dir="ltr">{u.phone}</p>
                                <span className={`text-[8px] px-1.5 py-0.5 rounded font-bold ${u.role === 'manager' ? 'bg-indigo-100 text-indigo-600 border border-indigo-200' : 'bg-gray-100 text-gray-500 border border-gray-200'}`}>
                                  {u.role === 'manager' ? 'رئيس قسم' : 'موظف'}
                                </span>
                             </div>
                          </div>
                       </div>
                       
                       <div className="space-y-2 mb-6">
                         {u.status === 'active' && !hasDevice ? (
                           <button onClick={() => setManualRegEmployee({ id: u.id, name: u.name })} className="w-full bg-indigo-50 text-indigo-600 py-3 rounded-2xl text-[10px] font-black border border-indigo-100 hover:bg-indigo-600 hover:text-white transition-all">تسجيل حضور يدوي</button>
                         ) : (
                           <div className="w-full bg-gray-100 text-gray-400 py-3 rounded-2xl text-[10px] font-bold text-center border">
                              {u.status === 'pending' ? 'بانتظار موافقة الإدارة' : 'الموظف يمتلك هاتف مربوط'}
                           </div>
                         )}
                       </div>

                       <div className="flex gap-2 pt-4 border-t border-gray-100">
                          {user.role === 'admin' && (
                            <button onClick={() => toggleUserRole(u.phone)} className="flex-1 bg-white border border-gray-100 py-2 rounded-xl text-[9px] font-bold text-gray-600 hover:bg-indigo-50 hover:text-indigo-600 transition-colors">
                              {u.role === 'manager' ? 'خفض الرتبة' : 'ترقية لرئيس قسم'}
                            </button>
                          )}
                          <button onClick={() => resetEmployeeDevice(u.phone)} className="flex-1 bg-white border border-red-50 text-red-500 py-2 rounded-xl text-[9px] font-bold hover:bg-red-50 transition-colors">فك ربط الجهاز</button>
                       </div>
                    </div>
                   );
                })}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'dashboard' && (user.role === 'admin' || user.role === 'manager') && (
           <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                 <StatsCard title="إجمالي الموظفين" value={adminStats.totalEmployees} icon={<Users size={24} />} color="bg-indigo-600" />
                 <StatsCard title="الحضور اليوم" value={adminStats.presentToday} icon={<CheckCircle2 size={24} />} color="bg-green-600" />
                 <StatsCard title="المواقع النشطة" value={adminStats.activeSites} icon={<MapPin size={24} />} color="bg-orange-600" />
                 <StatsCard title="المخالفات" value={adminStats.violations} icon={<AlertCircle size={24} />} color="bg-red-600" />
              </div>
           </div>
        )}

        {activeTab === 'admin' && user.role === 'admin' && <AdminSites sites={workSites} onAddSite={addSite} onDeleteSite={deleteSite} />}
      </main>

      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white/95 border-t px-6 py-4 flex justify-between items-center z-50 pb-10 rounded-t-[2.5rem] shadow-2xl no-print">
        {[
          { id: 'home', icon: Clock, label: 'الرئيسية' },
          { id: 'history', icon: History, label: 'السجلات' },
          { id: 'departments', icon: LayoutGrid, label: 'الأقسام', adminOrManager: true },
          { id: 'employees', icon: Users, label: 'الكوادر', adminOrManager: true },
        ].filter(t => !t.adminOrManager || user.role !== 'employee').map(item => (
          <button key={item.id} onClick={() => setActiveTab(item.id as any)} className={`flex flex-col items-center gap-1 ${activeTab === item.id ? 'text-indigo-600 scale-110' : 'text-gray-400'} transition-all`}>
            <item.icon className="w-5 h-5" /><span className="text-[9px] font-black">{item.label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
};

export default App;