
import { WorkSite, User, AttendanceRecord, AttendanceStatus } from './types';

export const INITIAL_WORK_SITES: WorkSite[] = [
  {
    id: 'site-1',
    lat: 24.7136,
    lng: 46.6753,
    radius: 200,
    name: "المقر الرئيسي - الرياض"
  },
  {
    id: 'site-2',
    lat: 24.7742,
    lng: 46.7386,
    radius: 500,
    name: "فرع المطار - الرياض"
  }
];

export const DEPARTMENTS = [
  "الموارد البشرية",
  "تقنية المعلومات",
  "المبيعات والتسويق",
  "المالية",
  "العمليات",
  "خدمة العملاء",
  "الإدارة العليا"
];

// Add 'status' property to fix the TypeScript error on line 31
export const CURRENT_USER: User = {
  id: 'user-1',
  name: 'أحمد محمد',
  phone: '0501234567',
  role: 'admin',
  department: 'الإدارة العليا',
  status: 'active'
};

export const MOCK_HISTORY: AttendanceRecord[] = [
  {
    id: '1',
    userId: 'user-1',
    userName: 'أحمد محمد',
    type: AttendanceStatus.IN,
    timestamp: new Date(Date.now() - 3600000 * 8),
    location: { lat: 24.7135, lng: 46.6752 },
    isWithinRange: true,
    distance: 15,
    siteName: "المقر الرئيسي - الرياض"
  }
];
