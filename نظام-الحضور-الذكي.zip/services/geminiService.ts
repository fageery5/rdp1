
import { GoogleGenAI, Type } from "@google/genai";
import { AttendanceRecord } from "../types";

// Always initialize the client using the apiKey named parameter from process.env.API_KEY.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const searchLocation = async (query: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `ابحث عن الموقع التالي واستخرج إحداثياته (خط العرض وخط الطول) واسمه الكامل: "${query}". 
      يجب أن تعيد النتيجة بتنسيق نصي واضح يحتوي على: الاسم، خط العرض، خط الطول.`,
      config: {
        tools: [{ googleMaps: {} }],
      },
    });

    const text = response.text || "";
    
    // Rule: If Google Maps is used, MUST extract URLs from groundingChunks and list them on the web app.
    // This includes groundingChunks.maps.uri and groundingChunks.maps.placeAnswerSources.reviewSnippets.
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const urls: string[] = [];
    
    groundingChunks.forEach((chunk: any) => {
      if (chunk.maps?.uri) {
        urls.push(chunk.maps.uri);
      }
      if (chunk.maps?.placeAnswerSources?.reviewSnippets) {
        chunk.maps.placeAnswerSources.reviewSnippets.forEach((snippet: any) => {
          if (snippet.uri) {
            urls.push(snippet.uri);
          }
        });
      }
    });

    // Extract coordinates from text response using regex.
    const coordMatches = text.match(/(-?\d+\.\d+)/g);

    if (coordMatches && coordMatches.length >= 2) {
      return {
        name: query,
        lat: parseFloat(coordMatches[0]),
        lng: parseFloat(coordMatches[1]),
        description: text,
        urls: Array.from(new Set(urls)) // Return unique URLs to avoid duplicates.
      };
    }
    
    return { error: "لم يتم العثور على إحداثيات دقيقة. يرجى المحاولة بوصف أدق." };
  } catch (error) {
    console.error("Search Error:", error);
    return { error: "حدث خطأ أثناء البحث عن الموقع." };
  }
};
