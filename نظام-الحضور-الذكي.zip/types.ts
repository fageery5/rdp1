
export enum AttendanceStatus {
  IN = 'حضور',
  OUT = 'انصراف',
}

export interface AttendanceRecord {
  id: string;
  userId: string;
  userName: string;
  userPhone?: string;
  type: AttendanceStatus;
  timestamp: Date;
  location: {
    lat: number;
    lng: number;
  };
  isWithinRange: boolean;
  distance: number;
  siteName?: string;
  isManual?: boolean; 
  recordedBy?: string; 
  recordedByName?: string; 
}

export interface User {
  id: string;
  name: string;
  phone: string;
  role: 'admin' | 'manager' | 'employee';
  department?: string;
  deviceId?: string;
  status: 'active' | 'pending'; // حالة الحساب
  addedBy?: string; // من قام بإضافة الموظف
}

export interface WorkSite {
  id: string;
  lat: number;
  lng: number;
  radius: number; 
  name: string;
}
