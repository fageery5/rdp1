
import React, { useState } from 'react';
import { User, Phone, LogIn, Clock, ShieldCheck, Building2, Smartphone, AlertTriangle } from 'lucide-react';

interface LoginProps {
  onLogin: (name: string, phone: string, department: string) => string | null;
  departments: string[];
}

const Login: React.FC<LoginProps> = ({ onLogin, departments }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [department, setDepartment] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (name.trim() && phone.trim() && department) {
      const loginError = onLogin(name, phone, department);
      if (loginError) {
        setError(loginError);
      }
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-[2.5rem] shadow-2xl shadow-blue-100 overflow-hidden border border-gray-100">
        <div className="bg-blue-600 p-10 text-white text-center relative">
          <div className="absolute top-0 right-0 p-8 opacity-10">
            <Clock size={120} />
          </div>
          <div className="relative z-10">
            <div className="bg-white/20 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 backdrop-blur-md border border-white/30">
              <Clock className="w-8 h-8" />
            </div>
            <p className="text-blue-200 text-xs font-bold mb-1 tracking-widest uppercase">مستشفى دنقلا التخصصي</p>
            <h1 className="text-2xl font-black">نظام الحضور الذكي</h1>
            <p className="text-blue-100 text-sm mt-2 font-medium opacity-80">سجل دخولك لبدء يومك</p>
          </div>
        </div>

        <div className="p-10 space-y-8">
          {error && (
            <div className="bg-red-50 border border-red-100 p-4 rounded-2xl flex items-start gap-3 animate-in fade-in slide-in-from-top-2">
              <AlertTriangle className="text-red-500 w-5 h-5 shrink-0 mt-0.5" />
              <div>
                <p className="text-red-800 text-xs font-bold leading-relaxed">{error}</p>
                <p className="text-red-600 text-[10px] mt-1">يرجى التواصل مع المدير لإعادة تعيين الجهاز.</p>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700 block mr-1">الاسم الكامل</label>
              <div className="relative group">
                <User className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-blue-600 transition-colors w-5 h-5" />
                <input
                  type="text"
                  required
                  placeholder="أدخل اسمك كما هو في السجلات"
                  className="w-full bg-gray-50 border border-gray-100 rounded-2xl pr-12 pl-4 py-4 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-sm font-medium"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700 block mr-1">القسم</label>
              <div className="relative group">
                <Building2 className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-blue-600 transition-colors w-5 h-5" />
                <select
                  required
                  className="w-full bg-gray-50 border border-gray-100 rounded-2xl pr-12 pl-4 py-4 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-sm font-medium appearance-none cursor-pointer"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                >
                  <option value="" disabled>اختر القسم الذي تعمل به</option>
                  {departments.map((dept) => (
                    <option key={dept} value={dept}>{dept}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700 block mr-1">رقم الهاتف</label>
              <div className="relative group">
                <Phone className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-blue-600 transition-colors w-5 h-5" />
                <input
                  type="tel"
                  required
                  placeholder="05XXXXXXXX"
                  dir="ltr"
                  className="w-full bg-gray-50 border border-gray-100 rounded-2xl pr-12 pl-4 py-4 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-sm font-medium text-right"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-2xl shadow-lg shadow-blue-100 transition-all transform active:scale-[0.98] flex items-center justify-center gap-2"
            >
              <LogIn className="w-5 h-5" />
              <span>دخول للنظام</span>
            </button>
          </form>

          <div className="pt-6 border-t border-gray-50 flex flex-col items-center gap-3">
             <div className="flex items-center gap-2 text-gray-400">
               <Smartphone className="w-4 h-4" />
               <p className="text-[10px] font-medium uppercase tracking-wider">هذا الجهاز سيتم ربطه بحسابك بشكل دائم</p>
             </div>
            <div className="flex items-center gap-2 text-gray-300">
              <ShieldCheck className="w-4 h-4" />
              <p className="text-[9px] font-medium uppercase">حماية من تعدد الأجهزة مفعلة</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
