
import React, { useState } from 'react';
import { WorkSite } from '../types';
import { Plus, Trash2, MapPin, Ruler, Navigation, Search, Loader2, CheckCircle, XCircle } from 'lucide-react';
import { searchLocation } from '../services/geminiService';

interface AdminSitesProps {
  sites: WorkSite[];
  onAddSite: (site: WorkSite) => void;
  onDeleteSite: (id: string) => void;
}

const AdminSites: React.FC<AdminSitesProps> = ({ sites, onAddSite, onDeleteSite }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  // Enhanced searchStatus to include grounding URLs for API guideline compliance
  const [searchStatus, setSearchStatus] = useState<{ type: 'success' | 'error', message: string, urls?: string[] } | null>(null);
  
  const [newSite, setNewSite] = useState<Partial<WorkSite>>({
    name: '',
    lat: 0,
    lng: 0,
    radius: 200
  });

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    setSearchStatus(null);
    
    const result = await searchLocation(searchQuery);
    
    setIsSearching(false);
    if ('error' in result) {
      setSearchStatus({ type: 'error', message: result.error || 'فشل البحث' });
    } else {
      setNewSite({
        ...newSite,
        name: result.name,
        lat: result.lat,
        lng: result.lng
      });
      // Capture grounding URLs to display them in the UI as required.
      setSearchStatus({ 
        type: 'success', 
        message: 'تم العثور على الموقع وتعبئة البيانات تلقائياً!',
        urls: result.urls
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newSite.name && newSite.lat && newSite.lng && newSite.radius) {
      onAddSite({
        id: Math.random().toString(36).substr(2, 9),
        name: newSite.name,
        lat: Number(newSite.lat),
        lng: Number(newSite.lng),
        radius: Number(newSite.radius)
      } as WorkSite);
      setIsAdding(false);
      setNewSite({ name: '', lat: 0, lng: 0, radius: 200 });
      setSearchQuery('');
      setSearchStatus(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-white p-6 rounded-3xl border border-gray-100 shadow-sm gap-4">
        <div>
          <h2 className="text-xl font-bold text-gray-800">إدارة مواقع العمل</h2>
          <p className="text-sm text-gray-500">حدد النطاق الجغرافي لكل فرع أو مكتب</p>
        </div>
        <button
          onClick={() => {
            setIsAdding(!isAdding);
            setSearchStatus(null);
          }}
          className="bg-blue-600 text-white px-6 py-2.5 rounded-xl flex items-center gap-2 hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 font-bold w-full sm:w-auto justify-center"
        >
          <Plus className="w-5 h-5" />
          {isAdding ? 'إلغاء' : 'إضافة موقع جديد'}
        </button>
      </div>

      {isAdding && (
        <div className="space-y-4 animate-in slide-in-from-top duration-300">
          {/* Advanced Search Feature */}
          <div className="bg-gradient-to-r from-blue-600 to-indigo-700 p-8 rounded-3xl shadow-xl text-white">
            <div className="flex items-center gap-2 mb-4">
              <Search className="w-6 h-6 text-blue-200" />
              <h3 className="text-lg font-bold">البحث السريع عبر الخرائط</h3>
            </div>
            <p className="text-blue-100 text-sm mb-6">ابحث عن أي مكان (مثل: مجمع ذا جيت، أو فرع جدة الرئيسي) وسنقوم بجلب الإحداثيات لك.</p>
            
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="ادخل اسم المكان أو العنوان..."
                className="flex-1 bg-white/10 border border-white/20 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-white/50 transition-all placeholder:text-white/40 text-white"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSearch()}
              />
              <button
                onClick={handleSearch}
                disabled={isSearching}
                className="bg-white text-blue-700 px-6 py-3 rounded-xl font-bold hover:bg-blue-50 transition-colors flex items-center gap-2 disabled:opacity-70"
              >
                {isSearching ? <Loader2 className="w-5 h-5 animate-spin" /> : 'بحث'}
              </button>
            </div>
            
            {searchStatus && (
              <div className={`mt-4 space-y-2 p-3 rounded-lg ${searchStatus.type === 'success' ? 'bg-green-500/20 text-green-100' : 'bg-red-500/20 text-red-100'}`}>
                <div className="flex items-center gap-2 text-sm">
                  {searchStatus.type === 'success' ? <CheckCircle className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                  {searchStatus.message}
                </div>
                {/* List grounding URLs as required by Gemini API guidelines for the Maps tool */}
                {searchStatus.urls && searchStatus.urls.length > 0 && (
                  <div className="mt-2 pl-6 border-t border-white/10 pt-2">
                    <p className="text-[10px] opacity-70 mb-1">المصادر المرجعية من خرائط جوجل:</p>
                    {searchStatus.urls.map((url, i) => (
                      <a key={i} href={url} target="_blank" rel="noopener noreferrer" className="block text-[10px] underline truncate hover:text-white">
                        {url}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="bg-white p-8 rounded-3xl border border-gray-100 shadow-lg space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 block">اسم الموقع</label>
                <input
                  type="text"
                  placeholder="مثال: المكتب الإقليمي"
                  required
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                  value={newSite.name}
                  onChange={e => setNewSite({ ...newSite, name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 block">نطاق الحضور (بالمتر)</label>
                <div className="relative">
                  <Ruler className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="number"
                    placeholder="200"
                    required
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-10 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                    value={newSite.radius}
                    onChange={e => setNewSite({ ...newSite, radius: Number(e.target.value) })}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 block">خط العرض (Latitude)</label>
                <div className="relative">
                  <Navigation className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="number"
                    step="any"
                    placeholder="24.7136"
                    required
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-10 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all text-left font-mono"
                    dir="ltr"
                    value={newSite.lat || ''}
                    onChange={e => setNewSite({ ...newSite, lat: Number(e.target.value) })}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 block">خط الطول (Longitude)</label>
                <div className="relative">
                  <Navigation className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5 rotate-90" />
                  <input
                    type="number"
                    step="any"
                    placeholder="46.6753"
                    required
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-10 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all text-left font-mono"
                    dir="ltr"
                    value={newSite.lng || ''}
                    onChange={e => setNewSite({ ...newSite, lng: Number(e.target.value) })}
                  />
                </div>
              </div>
            </div>
            <button
              type="submit"
              className="w-full bg-blue-600 text-white font-bold py-4 rounded-xl shadow-lg hover:bg-blue-700 transition-all transform active:scale-[0.98]"
            >
              حفظ الموقع في القائمة
            </button>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {sites.map(site => (
          <div key={site.id} className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm flex flex-col justify-between hover:border-blue-200 transition-all group">
            <div className="flex gap-4 mb-4">
              <div className="bg-blue-50 p-3 rounded-xl h-fit group-hover:bg-blue-600 group-hover:text-white transition-colors">
                <MapPin className="w-6 h-6" />
              </div>
              <div className="space-y-1 overflow-hidden">
                <h3 className="font-bold text-gray-800 truncate">{site.name}</h3>
                <p className="text-xs text-gray-500 flex items-center gap-1">
                  <Ruler className="w-3 h-3" /> النطاق: {site.radius} متر
                </p>
                <p className="text-[10px] text-gray-400 font-mono truncate" dir="ltr">
                  {site.lat.toFixed(6)}, {site.lng.toFixed(6)}
                </p>
              </div>
            </div>
            <div className="flex justify-between items-center border-t border-gray-50 pt-4">
               <span className="text-[10px] text-gray-400">ID: {site.id}</span>
               <button
                onClick={() => onDeleteSite(site.id)}
                className="text-gray-300 hover:text-red-500 p-2 transition-colors rounded-lg hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminSites;
